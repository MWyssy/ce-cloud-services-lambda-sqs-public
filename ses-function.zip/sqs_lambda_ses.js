import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
const ses = new SESClient({ region: "eu-west-2" });

export const handler = async (event) => {
  let data = "Test";

  event.Records.forEach((record) => {
    const { body } = record;
    data = body;
  });

  const emailParams = new SendEmailCommand({
    Destination: {
      ToAddresses: ["mike@wyss.co.uk"],
    },
    Message: {
      Body: {
        Text: { Data: data },
      },
      Subject: { Data: "Test Email" },
    },
    Source: "mike@wyss.co.uk",
  });

  try {
    let response = await ses.send(emailParams);
    return response;
  } catch (err) {
    console.log("This has not worked!", err);
  } finally {
    console.log("It Worked!");
  }
};
